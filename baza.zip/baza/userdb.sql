-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 09, 2025 at 07:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `prezime` varchar(50) NOT NULL,
  `korisnicko_ime` varchar(50) NOT NULL,
  `sifra` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `ime`, `prezime`, `korisnicko_ime`, `sifra`, `email`, `role`) VALUES
(2, 'Marko', 'Marković', 'marko123', 'lozinka123', 'marko@email.com', 'user'),
(3, 'Jovana', 'Jovanović', 'jovana123', 'lozinka123', 'jovana@email.com', 'user'),
(4, 'Petar', 'Petrović', 'petar123', 'lozinka123', 'petar@email.com', 'admin'),
(5, 'Ana', 'Anić', 'ana123', 'lozinka123', 'ana@email.com', 'user'),
(6, 'Luka', 'Lukić', 'luka123', 'lozinka123', 'luka@email.com', 'user'),
(7, 'Ivana', 'Ivanović', 'ivana123', 'lozinka123', 'ivana@email.com', 'admin'),
(8, 'Nikola', 'Nikolić', 'nikola123', 'lozinka123', 'nikola@email.com', 'user'),
(9, 'Maja', 'Majić', 'maja123', 'lozinka123', 'maja@email.com', 'admin'),
(10, 'Filip', 'Filipović', 'filip123', 'lozinka123', 'filip@email.com', 'user'),
(11, 'Tamara', 'Tamarić', 'tamara123', 'lozinka123', 'tamara@email.com', 'user'),
(12, 'Stefan', 'Stefanović', 'stefan123', 'lozinka123', 'stefan@email.com', 'user'),
(13, 'Marija', 'Marić', 'marija123', 'lozinka123', 'marija@email.com', 'admin'),
(14, 'Davor', 'Davorić', 'davor123', 'lozinka123', 'davor@email.com', 'user'),
(15, 'Jelena', 'Jelenić', 'jelena123', 'lozinka123', 'jelena@email.com', 'admin'),
(16, 'Vanja', 'Vanjić', 'vanja123', 'lozinka123', 'vanja@email.com', 'user'),
(17, 'Igor', 'Igorić', 'igor123', 'lozinka123', 'igor@email.com', 'admin'),
(18, 'Sandra', 'Sandić', 'sandra123', 'lozinka123', 'sandra@email.com', 'user'),
(20, 'Lazar', 'Lazarević', 'lazar123', 'lozinka123', 'lazar@email.com', 'admin'),
(21, 'Bojan', 'Bojanić', 'bojan123', 'lozinka123', 'bojan@email.com', 'user'),
(32, 'Dino', 'Devedzic', 'dinodino', '$2y$10$89h/UtWO120I12gBIvBDlufmBobgziGSdMXGSjVa6HMQGP715Lk62', 'dino2065@outlook.com', 'user'),
(33, 'adminko', 'adminko', 'adminko', '$2y$10$8jq5dJTJTjDHmF/8gxbid.EqBq3CBs3l9M3.eVcgIt0NDIjRK4IF6', 'adminko@gmail.com', 'admin'),
(35, 'Dino', 'DinoD', 'dinod', '$2y$10$cQnW1yE3Rt8BaZhSZgvSY.mRe396ECd5CygzOkX/HfDuRQR3Tw4Y.', 'dinodino@yahoo.com', 'user'),
(36, 'proba', 'proba', 'probaproba', '$2y$10$7ejHwN9JID8g4RSbgmSBdOqbWEDYlDoeRj6UClNMZOgrbdBWMVkxm', 'proba@gmail.com', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `naslov` varchar(255) NOT NULL,
  `sadrzaj` text NOT NULL,
  `autor` varchar(100) NOT NULL,
  `datum_objave` datetime NOT NULL DEFAULT current_timestamp(),
  `slika` varchar(255) NOT NULL DEFAULT 'default-image.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `naslov`, `sadrzaj`, `autor`, `datum_objave`, `slika`) VALUES
(6, 'Kako optimizovati upite', 'Saveti za optimizaciju SQL upita.', 'Stefan Ilić', '2025-01-03 21:20:57', 'default-image.jpg'),
(7, 'SQL i   NoSQL BAZE PODATAKA', 'Poređenje SQLi NoSQL baza podataka.', 'Lazar Popović', '2024-12-25 12:00:00', 'default-image.jpg'),
(8, 'Kreiranje tabela', 'Članak o kreiranju tabela u SQL-u.', 'Nina Savić', '2025-01-03 21:20:57', 'default-image.jpg'),
(9, 'Indeksi u bazama podataka', 'Razumevanje uloge indeksa u SQL-u.', 'Filip Filipović', '2025-01-03 09:15:00', 'default-image.jpg'),
(10, 'SQL join operacije', 'Detalji o različitim vrstama join operacija.', 'Tamara Todorović', '2024-12-30 11:20:00', 'default-image.jpg'),
(11, 'Stored Procedure', 'Kako koristiti stored procedure u SQL-u.', 'Dimitrije Lukić', '2025-01-03 21:20:57', 'default-image.jpg'),
(12, 'Sigurnost u bazama podataka', 'Saveti za obezbeđivanje baza podataka.', 'Sara Marković', '2025-01-03 21:20:57', 'default-image.jpg'),
(13, 'SQL i Python', 'Kako koristiti SQL u Python aplikacijama.', 'Nemanja Radović', '2024-12-28 14:45:00', 'default-image.jpg'),
(14, 'Agregatne funkcije', 'Korišćenje SQL agregatnih funkcija.', 'Katarina Pavlović', '2025-01-04 10:00:00', 'default-image.jpg'),
(15, 'Paginacija u SQL-u', 'Saveti za implementaciju paginacije.', 'Mihailo Živković', '2025-01-05 12:30:00', 'default-image.jpg'),
(16, 'SQL Backup', 'Kako napraviti i vratiti SQL backup.', 'Ana Marinković', '2025-01-03 21:20:57', 'default-image.jpg'),
(17, 'SQL Triggers', 'Razumevanje SQL okidača.', 'Stefan Perić', '2024-12-29 16:10:00', 'default-image.jpg'),
(18, 'SQL Constraints', 'Kako koristiti ograničenja u SQL-u.', 'Nikola Krstić', '2025-01-03 21:20:57', 'default-image.jpg'),
(19, 'SQL alatke', 'Pregled popularnih SQL alatki.', 'Maja Stanković', '2025-01-06 13:15:00', 'default-image.jpg'),
(20, 'Transakcije u SQL-u', 'Detalji o SQL transakcijama.', 'Petar Petrović', '2024-12-27 09:00:00', 'default-image.jpg'),
(24, 'nlk', 'jlkjl', 'dino', '2025-01-08 16:08:51', '677e95034694a-slika1.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `korisnicko_ime` (`korisnicko_ime`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
