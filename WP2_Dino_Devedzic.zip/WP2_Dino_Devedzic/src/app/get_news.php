<?php
include 'db_connect.php';


header("Access-Control-Allow-Origin: *"); //bilo koji domen moze i lclhost
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");


$query = "SELECT id, naslov, sadrzaj, autor, datum_objave, slika FROM vijesti";
$result = $conn->query($query);

$news = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $news[] = $row;
    }
}

echo json_encode($news); // Mora biti niz
$conn->close();
?>
