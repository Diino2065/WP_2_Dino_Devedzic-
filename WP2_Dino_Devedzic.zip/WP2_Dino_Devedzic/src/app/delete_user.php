<?php
include 'db_connect.php';


header("Access-Control-Allow-Origin: http://localhost:4200");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");


if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    // Čitanje tijela zahtjeva
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? null; 

    if ($id) {
        $sql = "DELETE FROM korisnici WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            echo json_encode(['message' => 'Korisnik uspješno izbrisan.']);
        } else {
            echo json_encode(['error' => 'Greška prilikom brisanja korisnika.']);
        }
        $stmt->close();
    } else {
        echo json_encode(['error' => 'ID nije poslan.']);
    }
} else {
    echo json_encode(['error' => 'Nepodržan zahtjev.']);
}

$conn->close();
?>
