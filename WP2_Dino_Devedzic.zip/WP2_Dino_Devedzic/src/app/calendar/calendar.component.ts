import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepicker } from '@angular/material/datepicker';
//import { MatDatepickerToggleModule } from '@angular/material/datepicker';
import { MatLabel } from '@angular/material/form-field'
import { NgIf } from '@angular/common';
import { MatSuffix } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { MatFormField } from '@angular/material/form-field';
import { MatButton } from '@angular/material/button';
import { MatCalendar } from '@angular/material/datepicker';
import { CommonModule } from '@angular/common';
import { MatCalendarBody } from '@angular/material/datepicker';
import { HttpClientModule } from '@angular/common/http';
import { MatCalendarCell } from '@angular/material/datepicker';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { MatCommonModule } from '@angular/material/core';
import { of } from 'rxjs';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-calendar',
  standalone: true,
  imports: [
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatCommonModule,
    MatButtonModule,
    HttpClientModule,
    CommonModule,
    NgIf,
    HeaderComponent,
    FooterComponent
],
    providers: [],
  templateUrl: './calendar.component.html',
  styleUrl: './calendar.component.css',
  template: `
 <!-- <h2>Calendar</h2>
  <mat-calendar [(selected)]="selectedDate"></mat-calendar>
  <p *ngIf="selectedDate">You selected: {{ selectedDate | date }}</p>-->
`,

})

export class CalendarComponent implements OnInit {
  currentYear: number = new Date().getFullYear();
  currentMonth: number = new Date().getMonth();
  selectedDate: Date | null = null;
  daysInMonth: number[] = [];
  weekdays: string[] = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  months: string[] = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  news: any[] = []; // Drži vijesti za odabrani datum
  filteredNews: any[] = []; // Filtrirane vijesti na osnovu datuma

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.generateDaysInMonth();
  }

  generateDaysInMonth(): void {
    const daysInCurrentMonth = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();
    this.daysInMonth = Array.from({ length: daysInCurrentMonth }, (_, i) => i + 1);
  }

  onDayClick(month: number, day: number): void {
    this.selectedDate = new Date(this.currentYear, month, day);
    const formattedDate = this.selectedDate.toISOString().split('T')[0]; // Format: YYYY-MM-DD

    //  API vijesti za odabrani datum
    this.http.get<any[]>(`http://localhost/WP2_Dino_Devedzic/src/app/get_news.php?date=${formattedDate}`)
      .subscribe(
        (data) => {
          this.news = data;  
          this.filterNews(); 
        },
        (error) => {
          console.error('Greška pri dohvaćanju vijesti:', error);
          this.news = [];
        }
      );
  }

  filterNews(): void {
    if (this.selectedDate) {
      const currentDate = new Date();
      const selectedDate = new Date(this.selectedDate);

      
      this.filteredNews = this.news.filter(newsItem => {
        const newsDate = new Date(newsItem.datum_objave); 
        return newsDate <= currentDate && newsDate >= selectedDate; 
      });
    }
  }
}