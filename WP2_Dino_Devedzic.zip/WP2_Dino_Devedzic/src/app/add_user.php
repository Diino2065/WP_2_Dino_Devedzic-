<?php

header('Access-Control-Allow-Origin: *'); // 
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header("Access-Control-Allow-Credentials: true");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    
    http_response_code(200);
    exit();
}


include 'db_connect.php';

// zahtjev cita podatke
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['ime'], $data['prezime'], $data['korisnicko_ime'], 
          $data['sifra'], $data['potvrda_sifre'], $data['email'], $data['role'])) {

    $ime = $data['ime'];
    $prezime = $data['prezime'];
    $korisnicko_ime = $data['korisnicko_ime'];
    $sifra = $data['sifra'];
    $potvrda_sifre = $data['potvrda_sifre'];
    $email = $data['email'];
    $role = $data['role'];

    if ($sifra !== $potvrda_sifre) {
        echo json_encode(['status' => 'error', 'message' => 'Šifre se ne poklapaju.']);
        exit();
    }

    // hesh
    $hashovana_sifra = password_hash($sifra, PASSWORD_DEFAULT);

   
    $sql = "INSERT INTO korisnici (ime, prezime, korisnicko_ime, sifra, email, role) 
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssss', $ime, $prezime, $korisnicko_ime, $hashovana_sifra, $email, $role);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Korisnik uspešno dodat.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Greška pri dodavanju korisnika: ' . $conn->error]);
    }

    
    $stmt->close();
    $conn->close();
} else {
    
    //ovo se izvrsi ako nedostaju parametri
    echo json_encode(['status' => 'error', 'message' => 'Nedostaju obavezni parametri.']);
    exit();
}
?>
