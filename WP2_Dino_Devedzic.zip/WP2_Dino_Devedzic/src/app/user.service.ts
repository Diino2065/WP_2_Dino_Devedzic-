import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private apiUrl = 'http://localhost/WP2_Dino_Devedzic/src/app/get_users.php'; // URL do PHP fajla
  private addUserUrl = 'http://localhost/WP2_Dino_Devedzicic/src/app/add_user.php'; // URL for adding a user
  private deleteUserUrl = 'http://localhost/WP2_Dino_Devedzic/src/app/delete_user.php'; // URL za brisanje korisnika
  constructor(private http: HttpClient) {}

  getUsers(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl);
    
  }

  addUser(userData: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/add_user.php`, userData);
  }
  

  deleteUser(id: number): Observable<any> {
    
    return this.http.request('DELETE', this.deleteUserUrl, {
      body: { id }
    });
  }

  
   



  }
  
  
  
  
  

