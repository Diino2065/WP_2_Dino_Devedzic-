<?php

include 'db_connect.php'; 

// CORS zaglavlja kako bi omogućili zahtjeve s bilo kojeg izvora
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Obrada preflight zahtjeva za OPTIONS metodu
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

 // Uključuje konekciju s bazom podataka

// Provjeravamo je li 'id' poslan putem POST metode
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Pripremimo SQL upit za ažuriranje
    $sql = "UPDATE vijesti SET ";

    // Polja koja će se ažurirati
    $fields = [];
    $params = [];

    // Provjeravamo i dodajemo 'naslov' ako je prisutan
    if (isset($_POST['naslov'])) {
        $fields[] = "naslov = ?";
        $params[] = $_POST['naslov'];
    }

    // Provjeravamo i dodajemo 'sadrzaj' ako je prisutan
    if (isset($_POST['sadrzaj'])) {
        $fields[] = "sadrzaj = ?";
        $params[] = $_POST['sadrzaj'];
    }

    // Provjeravamo i dodajemo 'autor' ako je prisutan
    if (isset($_POST['autor'])) {
        $fields[] = "autor = ?";
        $params[] = $_POST['autor'];
    }

    // Obrada slike
    if (isset($_FILES['slika']) && $_FILES['slika']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['slika']['tmp_name'];
        $fileName = $_FILES['slika']['name'];
        $fileDest = 'uploads/' . uniqid() . '_' . $fileName;

        // Provjera tipa slike
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($_FILES['slika']['type'], $allowedTypes)) {
            echo json_encode(['status' => 'error', 'message' => 'Nevažeći tip datoteke. Dozvoljeni su samo JPG, PNG i GIF.']);
            exit();
        }

        // Premještanje slike u odgovarajući direktorij
        if (move_uploaded_file($fileTmpPath, $fileDest)) {
            $fields[] = "slika = ?";
            $params[] = $fileDest;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Greška pri uploadu slike.']);
            exit();
        }
    }

    // Dodavanje WHERE uslova za ažuriranje specifične vijesti prema ID-u
    $sql .= implode(", ", $fields) . " WHERE id = ?";

    // Priprema i bindanje parametara
    $stmt = $conn->prepare($sql);

    // Bindanje dinamičkih parametara
    $params[] = $id;  // ID se dodaje u parametre, ali se neće ispisivati
    $types = str_repeat('s', count($params) - 1) . 'i';  // Pretpostavljamo da su svi podaci osim ID-a stringovi
    $stmt->bind_param($types, ...$params);

    // Izvršavanje upita
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Vijest uspješno ažurirana.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Greška pri ažuriranju vijesti: ' . $stmt->error]);
    }

    // Zatvaranje konekcije
    $stmt->close();
    $conn->close();
} else {
    // Ako nije poslan ID, prikazujemo grešku
    echo json_encode(['status' => 'error', 'message' => 'ID je obavezan.']);
}
?>
