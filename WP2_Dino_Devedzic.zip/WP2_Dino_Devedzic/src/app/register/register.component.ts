import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { FooterComponent } from "../footer/footer.component";  // Import za Router

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, FooterComponent],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent {
  ime: string = '';
  prezime: string = '';
  korisnickoIme: string = '';
  sifra: string = '';
  potvrdaSifre: string = '';
  email: string = '';
  role: string = 'user'; // Automatski  uloga "user"

  constructor(private http: HttpClient, private router: Router) {} // Dodajemo Router

  onAddUser() {
    if (this.sifra !== this.potvrdaSifre) {
      alert('Šifre se ne poklapaju!');
      return;
    }

    const userData = {
      ime: this.ime,
      prezime: this.prezime,
      korisnicko_ime: this.korisnickoIme,
      sifra: this.sifra,
      potvrda_sifre: this.potvrdaSifre,
      email: this.email,
      role: this.role,  
    };

  
    this.http.post('http://localhost/WP2_Dino_Devedzic/src/app/add_user.php', userData).subscribe(
      (response: any) => {
        if (response.status === 'success') {
          alert('Korisnik uspešno registriran!');
  
          this.router.navigate(['/home']);  
        } else {
          alert('Greška: ' + response.message);
        }
      },
      (error) => {
        alert('Došlo je do greške pri registraciji korisnika.');
      }
    );
  }
}
