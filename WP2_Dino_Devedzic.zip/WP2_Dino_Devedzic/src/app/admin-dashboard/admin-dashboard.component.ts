import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AddUserComponent } from '../add-user/add-user.component';
import { RouterModule } from '@angular/router';
import { RouterLink } from '@angular/router';
import { UserService } from '../user.service';
import { FooterComponent } from '../footer/footer.component';


@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
  imports:[HeaderComponent, CommonModule,FormsModule,AddUserComponent,RouterLink,FooterComponent],
  standalone:true
})


export class AdminDashboardComponent  {
  users: any[] = []; // Lista korisnika

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    console.log('AdminDashboardComponent je učitan!');
    this.fetchUsers(); //  kad sekomponenta učita poziva se fetch
  }

  fetchUsers(): void {
    this.userService.getUsers().subscribe(
      (data) => {
        this.users = data; 
        console.log(this.users)
      },
      (error) => {
        console.error('Greška prilikom dohvatanja korisnika:', error);
      }
    );
  }
}