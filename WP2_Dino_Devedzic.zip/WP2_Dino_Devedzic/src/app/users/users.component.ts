import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { RouterLink } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, RouterLink, HeaderComponent, FooterComponent],
})
export class UsersComponent implements OnInit {
  users: any[] = []; 

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.getUsers(); // inicijalizije komponentu i kupi korisnike
  }

  
  getUsers(): void {
    this.userService.getUsers().subscribe({
      next: (data) => {
        this.users = data;
      },
      error: (err) => {
        console.error('Greška pri učitavanju korisnika:', err);
      }
    });
  }

  deleteUser(id: number): void {
    if (confirm('Jeste li sigurni da želite izbrisati ovog korisnika?')) {
      this.userService.deleteUser(id).subscribe({
        next: (response) => {
          
          this.users = this.users.filter(user => user.id !== id);
          console.log(`Korisnik sa ID: ${id} je uspješno izbrisan.`);
          console.log('Server response:', response); 
        },
        error: (err) => {
          console.error('Greška pri brisanju korisnika:', err);
        }
      });
    }
}



}
