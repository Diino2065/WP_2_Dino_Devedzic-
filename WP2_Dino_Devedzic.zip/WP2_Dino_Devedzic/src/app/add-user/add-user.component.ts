import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-add-user',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-user.component.html',
  styleUrl: './add-user.component.css'
})
export class AddUserComponent {
  ime: string = '';
  prezime: string = '';
  korisnickoIme: string = '';
  sifra: string = '';
  potvrdaSifre: string = '';
  email: string = '';
  role: string = 'user';

  constructor(private http: HttpClient) {}

  onAddUser() {
    if (this.sifra !== this.potvrdaSifre) {
      alert('Šifre se ne poklapaju!');
      return;
    }

    const userData = {
      ime: this.ime,
      prezime: this.prezime,
      korisnicko_ime: this.korisnickoIme,
      sifra: this.sifra,
      potvrda_sifre: this.potvrdaSifre,
      email: this.email,
      role: this.role,
    };

    this.http.post('http://localhost/WP2_Dino_Devedzic/src/app/add_user.php', userData).subscribe(
      (response: any) => {
        if (response.status === 'success') {
          alert('Korisnik uspešno dodat!');
        } else {
          alert('Greška: ' + response.message);
        }
      },
      (error) => {
        alert('Došlo je do greške pri dodavanju korisnika.');
      }
    );
  }
}