<?php

$servername = "localhost";  
$username = "root";         
$password = "";             
$dbname = "userdb";       


$conn = new mysqli($servername, $username, $password, $dbname);

// provjera (radi)
if ($conn->connect_error) {
    die("Ne mogu da se povežem: " . $conn->connect_error);
} 

?>
