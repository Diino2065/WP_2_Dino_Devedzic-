import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { RouterModule } from '@angular/router';
import { UserService } from './user.service';
import { FooterComponent } from "./footer/footer.component";
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FooterComponent,FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  /*template: `
  <router-outlet></router-outlet>
`,*/
})
export class AppComponent {
  title = 'WP2_Dino_Devedzic';
  
}
