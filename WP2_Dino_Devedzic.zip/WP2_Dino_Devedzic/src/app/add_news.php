<?php
include 'db_connect.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

$naslov = $_POST['naslov'] ?? null;
$sadrzaj = $_POST['sadrzaj'] ?? null;
$autor = $_POST['autor'] ?? null;
$slika = $_FILES['slika'] ?? null;

if ($naslov && $sadrzaj && $autor) {
    $datum_objave = date('Y-m-d H:i:s');
    $slikaIme = null;

    // Provjeri je li slika prenesena
    if ($slika && $slika['tmp_name']) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $slikaIme = uniqid() . '-' . basename($slika['name']);
        $uploadFile = $uploadDir . $slikaIme;

        if (!move_uploaded_file($slika['tmp_name'], $uploadFile)) {
            echo json_encode(['status' => 'error', 'message' => 'Greška pri prijenosu slike']);
            exit;
        }
    }

    $query = "INSERT INTO vijesti (naslov, sadrzaj, autor, datum_objave, slika) 
              VALUES ('$naslov', '$sadrzaj', '$autor', '$datum_objave', '$slikaIme')";

    if ($conn->query($query)) {
        echo json_encode(['status' => 'success', 'message' => 'Vijest dodana']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Greška pri dodavanju vijesti']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Podaci nisu ispravno poslani']);
}

$conn->close();
?>
