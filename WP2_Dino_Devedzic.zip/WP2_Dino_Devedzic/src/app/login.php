<?php
include 'db_connect.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// cita post json fomrat
$data = json_decode(file_get_contents("php://input"));


// var_dump($data);  // prikaz get podatka

if ($data && isset($data->username) && isset($data->password)) {
    $username = $data->username;
    $password = $data->password;

    
    if ($username === 'admin' && $password === 'admin') {
        echo json_encode([
            'status' => 'success',
            'message' => 'Admin login successful',
            'role' => 'admin',
            'redirect' => 'admin'
        ]);
        exit();
    }

    
    $sql = "SELECT id, ime, korisnicko_ime, email, sifra, role FROM korisnici WHERE korisnicko_ime = ?";
    $stmt = $conn->prepare($sql);
    
    
    if ($stmt === false) {
        echo json_encode(['status' => 'error', 'message' => 'SQL query preparation failed.']);
        exit();
    }

    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

   
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
       
        
 
        if (password_verify($password, $user['sifra'])) {
           
            echo json_encode([
                'status' => 'success',
                'message' => 'Login successful',
                'role' => $user['role'],
                'redirect' => ($user['role'] === 'admin') ? 'admin' : 'home'
            ]);
        } else {
            
            echo json_encode(['status' => 'error', 'message' => 'Pogrešna lozinka.']);
        }
    } else {
        
        echo json_encode(['status' => 'error', 'message' => 'Korisnik nije pronađen.']);
    }

   
    $stmt->close();
} else {
    // salje json provjera je li vlaidan 
    echo json_encode(['status' => 'error', 'message' => 'Podaci nisu ispravno poslati.']);
}

$conn->close();
?>
