import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { FooterComponent } from "../footer/footer.component";
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterLink, FooterComponent],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  //email: string = '';
  password: string = '';
  username: string = '';

  //constructor(private router: Router) {}

/*
onLogin() {
  console.log(`Login attempt: Username = ${this.username}, Password = ${this.password}`);
  if (this.username === 'admin' && this.password === 'admin') {
    console.log('Admin login success');  // Ovaj log treba da se pojavljuje kada se prijaviš kao admin
    this.router.navigate(['/admin']);
  } else if (this.username && this.password) {
    console.log('User login success');
    this.router.navigate(['/home']);
  } else {
    alert('Please enter your credentials.');
  }  
}
}*/
// (PROVJERA SAMO ZA ADMINA PRIJE IMPLEMENTACIJE BAZE)



constructor(private http: HttpClient, private router: Router) {}

onLogin() {
  console.log(`Login attempt: Username = ${this.username}, Password = ${this.password}`);

  
  if (this.username && this.password) {

    //  API  check  imena i lozinke
    this.http.post<any>('http://localhost/WP2_Dino_Devedzic/src/app/login.php', {
      username: this.username,
      password: this.password
    })
    .pipe(
      catchError(err => {
        console.error('Login error', err);
        alert('Login failed. Please try again.');
        return of(null);
      })
    )
    .subscribe(response => {
      if (response) {
        // Ako je uspešan login, prebacujemo korisnika na odgovarajuću stranu
        if (response.status === 'success') {
          console.log('User login success');
          
          // Ako je uloga admin, preusmeravamo ga na admin dashboard
          if (response.role === 'admin') {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/home']);
          }
        } else {
          alert(response.message || 'An error occurred. Please try again.');
        }
      } else {
        alert('An error occurred. Please try again.');
      }
    });
  } else {
    alert('Please enter your credentials.');
  }
}






}
