import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class NewsService {
  private apiUrl = `http://localhost/WP2_Dino_Devedzic/src/app`; // Glavni URL

  constructor(private http: HttpClient) {}

  getNews(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/get_news.php`);
  }

        deleteNews(id: number): Observable<any> {
            return this.http.delete<any>(`${this.apiUrl}/delete_news.php?id=${id}`);
          }
      
  addNews(news: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/add_news.php`, news);
  }

  updateNews(news: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/update_news.php`, news).pipe(
    );
  }


  

}
