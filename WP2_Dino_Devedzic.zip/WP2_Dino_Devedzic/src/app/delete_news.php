<?php

include 'db_connect.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");


if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    echo json_encode(["status" => "error", "message" => "Dozvoljena je samo DELETE metoda."]);
    http_response_code(405); 
    exit();
}

// Dohvatanje ulaznih podataka
$input = json_decode(file_get_contents("php://input"), true);

// Provjera da li je ID postavljen
if (!isset($input['id']) || empty($input['id'])) {
    echo json_encode(["status" => "error", "message" => "ID nije postavljen ili je prazan."]);
    http_response_code(400); // nepravilan zahtjev
    exit();
}

$id = intval($input['id']); // pretvara u cijeli broj za sigurnsot 


$query = "DELETE FROM vijesti WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(["status" => "success", "message" => "Vijest sa ID-em $id uspješno obrisana."]);
} else {
    echo json_encode(["status" => "error", "message" => "Greška pri brisanju vijesti: " . $stmt->error]);
}

$stmt->close();
?>
