import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule, DatePipe } from '@angular/common';
import { NewsService } from '../news.service';
import { FooterComponent } from '../footer/footer.component';


@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css'],
  providers: [DatePipe],
  standalone:true,
  imports: [FormsModule, CommonModule, FooterComponent]
})


export class NewsComponent implements OnInit {
  news: any[] = [];

  editingNews: any = null; // Trenutno  vijest (uredjivana)
  newNews: any = { naslov: '', sadrzaj: '', autor: '', datum_objave: new Date(), slika: '' };
  selectedFile: File | null = null;

  constructor(private http: HttpClient, private newsService: NewsService) { }

  ngOnInit(): void {
    this.getNews();
  }

  editNews(newsItem: any): void {
    this.editingNews = { ...newsItem }; // kopija 
  }
  cancelEdit(): void {
    this.editingNews = null; 
    this.selectedFile = null;
  }

/*
  // Funkcija za odabir datoteke
onFileSelected(event: any): void {
  this.selectedFile = event.target.files[0];
}*/

onFileSelected(event: any) {
  const file = event.target.files[0];
  if (file) {
    this.selectedFile = file;
  }
}



  // Dohvat vijesti//
    getNews() {
      this.newsService.getNews().subscribe(
        (data) => {
          console.log('Primljeni podaci:', data); 
          this.news = Array.isArray(data) ? data : []; 
        },
        (error) => {
          console.error('Greška pri dohvaćanju vijesti:', error);
        }
      );
    }
    
   
    addNews(): void {
      const formData = new FormData();
      formData.append('naslov', this.newNews.naslov);
      formData.append('sadrzaj', this.newNews.sadrzaj);
      formData.append('autor', this.newNews.autor);
      formData.append('slika', this.selectedFile || '');
    
      this.http.post('http://localhost/WP2_Dino_Devedzic/src/app/add_news.php', formData).subscribe(
        (response) => {
          this.getNews(); 
          this.newNews = { naslov: '', sadrzaj: '', autor: '', datum_objave: new Date(), slika: '' }; // from se restarzuje
          this.selectedFile = null; 
        },
        (error) => {
          console.error('Greška pri dodavanju vijesti:', error);
        }
      );
    }


        deleteNews(id: number): void {
          this.http.delete(`http://localhost/WP2_Dino_Devedzic/src/app/delete_news.php`, {
            body: { id },
          }).subscribe({
            next: (response) => {
              console.log("Vijest uspješno obrisana:", response);
        
              
              this.news = this.news.filter(newsItem => newsItem.id !== id);
            },
            error: (error) => {
              console.error("Greška pri brisanju vijesti:", error);
            },
          });
        }

     
        updateNews(): void {
          if (!this.editingNews.id) {
              alert('ID nije postavljen.');
              return;
          }
      
          console.log('Editing News ID:', this.editingNews.id); // id provjera
      
          const formData = new FormData();
          formData.append('id', this.editingNews.id);
          formData.append('naslov', this.editingNews.naslov);
          formData.append('sadrzaj', this.editingNews.sadrzaj);
          if (this.selectedFile) {
              formData.append('slika', this.selectedFile, this.selectedFile.name);
          }
      
          this.http.post('http://localhost/WP2_Dino_Devedzic/src/app/update_news.php', formData)
              .subscribe({
                  next: (response) => {
                      console.log('Update Successful:', response);
                      this.getNews(); // Reload poslije update 
                  },
                  error: (error) => {
                      console.error('Error updating news:', error);
                      alert('Došlo je do greške pri ažuriranju vijesti.');
                  }
              });
      }
      
        
        
    
    
    

}

