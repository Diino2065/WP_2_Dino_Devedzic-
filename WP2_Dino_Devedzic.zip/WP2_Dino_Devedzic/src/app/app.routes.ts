import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RouterModule} from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CalendarComponent } from './calendar/calendar.component';
import { FormsModule } from '@angular/forms';
import { AddUserComponent } from './add-user/add-user.component';
import { UsersComponent } from './users/users.component';
import { NewsComponent } from './news/news.component';

export const routes: Routes = [

  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent }, 
  { path: 'calendar', component: CalendarComponent },
 { path: 'admin', component: AdminDashboardComponent },  
 { path: '', redirectTo: '/home', pathMatch: 'full' },
{path: 'adduser', component: AddUserComponent}, 
{ path: 'users', component: UsersComponent },
{ path: 'news', component: NewsComponent }
];
