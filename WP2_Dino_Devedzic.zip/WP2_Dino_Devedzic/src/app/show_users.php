

<?php
include 'db_connect.php'; 

$sql = "SELECT id, ime, prezime, korisnicko_ime, email, role FROM korisnici";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Ime</th>
                <th>Prezime</th>
                <th>Korisničko ime</th>
                <th>Email</th>
                <th>Uloga</th>
            </tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['ime']}</td>
                <td>{$row['prezime']}</td>
                <td>{$row['korisnicko_ime']}</td>
                <td>{$row['email']}</td>
                <td>{$row['role']}</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "Nema korisnika.";
}

// Zatvaranje konekcije
$conn->close();
?>

