
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }


  logout() {
 // brise tokene 
    localStorage.removeItem('token'); 
    sessionStorage.removeItem('token'); 


    localStorage.removeItem('user');
  }

  
  isAuthenticated(): boolean {
    return !!localStorage.getItem('token'); // Ako postoji token korisnik je prijavljen
  }
}
