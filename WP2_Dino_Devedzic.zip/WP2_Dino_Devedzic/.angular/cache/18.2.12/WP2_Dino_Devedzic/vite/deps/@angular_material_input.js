import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-GADWR5CX.js";
import "./chunk-Z7VIIFLZ.js";
import "./chunk-VCFRR7U6.js";
import "./chunk-7MYW5AZ4.js";
import "./chunk-N4AAZ3KL.js";
import "./chunk-6GVHXLXB.js";
import "./chunk-5D3WSOWF.js";
import "./chunk-SMGPAF3V.js";
import "./chunk-WSXI74FV.js";
import "./chunk-LBBSG2YE.js";
import "./chunk-NGNUV6BG.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
