import {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-2RKRQTRR.js";
import "./chunk-7MYW5AZ4.js";
import "./chunk-N4AAZ3KL.js";
import "./chunk-6GVHXLXB.js";
import "./chunk-5D3WSOWF.js";
import "./chunk-SMGPAF3V.js";
import "./chunk-WSXI74FV.js";
import "./chunk-LBBSG2YE.js";
import "./chunk-NGNUV6BG.js";
export {
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
